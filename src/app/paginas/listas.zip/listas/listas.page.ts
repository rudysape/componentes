import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { DaaService } from '../../service/daa.service';

@Component({
  selector: 'app-listas',
  templateUrl: './listas.page.html',
  styleUrls: ['./listas.page.scss'],
})
export class ListasPage implements OnInit {
  usuarios: Observable<any>


  constructor(private dataservice: DaaService) {  //tenia que decir DataService

  }

  ngOnInit() {
      
      this.usuarios = this.dataservice.getUsuarios();
  }

  favorito(usuario){
    console.log(usuario);
  }

  compartir(usuario){
    console.log(usuario);

  }
  eliminar(usuario){
    console.log(usuario);
  }

}
